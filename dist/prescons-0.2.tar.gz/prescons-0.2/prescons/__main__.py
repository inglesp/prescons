from prescons import main

main()
